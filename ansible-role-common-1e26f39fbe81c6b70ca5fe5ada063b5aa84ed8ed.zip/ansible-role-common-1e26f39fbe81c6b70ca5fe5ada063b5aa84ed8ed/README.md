# ansible-kafka
Ansible role to deploy a kafka cluster
